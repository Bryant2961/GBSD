"""Baseline model utilities."""

