"""Uncertainty estimation utilities."""

