"""Guarded source-selection utilities."""

