"""Model definitions."""

